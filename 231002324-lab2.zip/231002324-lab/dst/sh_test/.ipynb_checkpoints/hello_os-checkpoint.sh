#!/bin/bash
# 检查参数数量
if [ $# -ne 2 ]; then
    echo "Usage: $0 <input_file> <output_file>"
    exit 1
fi

input_file="$1"   # 第一个参数是输入文件名
output_file="$2"  # 第二个参数是输出文件名

# 使用 sed 提取指定行
sed -n '8p;32p;128p;512p;1024p' "$input_file" > "$output_file"