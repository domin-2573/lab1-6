#include <stdio.h>
#include <assert.h>
#include "queue.h"

// 定义测试结构体
struct test_entry {
    int value;
    LIST_ENTRY(test_entry) entries;
};

// 定义链表头
LIST_HEAD(test_list, test_entry) mylist = LIST_HEAD_INITIALIZER(mylist);

int main() {
    struct test_entry e1 = {.value = 1};
    struct test_entry e2 = {.value = 2};
    struct test_entry e3 = {.value = 3};

    // 测试 1: 插入到空列表
    LIST_INSERT_TAIL(&mylist, &e1, entries);
    assert(LIST_FIRST(&mylist) == &e1);
    assert(e1.entries.le_next == NULL);
    assert(e1.entries.le_prev == &mylist.lh_first);

    // 测试 2: 插入第二个元素
    LIST_INSERT_TAIL(&mylist, &e2, entries);
    assert(LIST_FIRST(&mylist) == &e1);
    assert(e1.entries.le_next == &e2);
    assert(e2.entries.le_next == NULL);
    assert(e2.entries.le_prev == &e1.entries.le_next);

    // 测试 3: 插入第三个元素
    LIST_INSERT_TAIL(&mylist, &e3, entries);
    assert(LIST_FIRST(&mylist) == &e1);
    assert(e1.entries.le_next == &e2);
    assert(e2.entries.le_next == &e3);
    assert(e3.entries.le_next == NULL);
    assert(e3.entries.le_prev == &e2.entries.le_next);

    // 测试 4: 遍历链表
    printf("Traversing the list:\n");
    struct test_entry *p;
    LIST_FOREACH(p, &mylist, entries) {
        printf("%d -> ", p->value);
    }
    printf("NULL\n");

    printf("All tests passed!\n");
    return 0;
}