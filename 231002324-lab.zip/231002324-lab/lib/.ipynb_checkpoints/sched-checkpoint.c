#include <env.h>
#include <pmap.h>
#include <printf.h>

/* Overview:
 *  Implement simple round-robin scheduling.
 *  Search through 'envs' for a runnable environment ,
 *  in circular fashion statrting after the previously running env,
 *  and switch to the first such environment found.
 *
 * Hints:
 *  The variable which is for counting should be defined as 'static'.
 */
void sched_yield(void)
{
//	printf("in sched_yield\n");
	static int index = 0;
	static int time = 0;
	static struct Env * e;
	struct Env * temp;

	if (curenv == NULL && LIST_EMPTY(&env_sched_list[0]) && LIST_EMPTY(&env_sched_list[1])) {
		printf("There is no env to sched\n");
	}

	if (time == 0 || curenv == NULL) {
		if (LIST_EMPTY(&env_sched_list[index])) {
			index = 1 - index;
		} 
		if (!LIST_EMPTY(&env_sched_list[index])) {
			e = LIST_FIRST(&env_sched_list[index]);
			LIST_REMOVE(e, env_sched_link);
			time = e->env_pri;
			temp = LIST_FIRST(&env_sched_list[1 - index]);

			if (temp != NULL) {
				LIST_FOREACH(temp, &env_sched_list[1 - index], env_sched_link)
                                	if(LIST_NEXT(temp, env_sched_link)==NULL) break;
                                LIST_INSERT_AFTER(temp, e, env_sched_link);
			} else {
				LIST_INSERT_HEAD(&env_sched_list[1 - index], e, env_sched_link);
			}
		}
	}

	if (time > 0) {
		time--;
	}
//	printf("before env run\n");
//	show_env(e);	
	env_run(e);
//	printf("end sched_yield\n");
	return;
}
